from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app import models
from app.routers.auth import get_current_user

router = APIRouter()


@router.get("/")
def get_recommendations(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    """
    Stub for AI recommendations — Phase 2.
    Will use LangChain + vector embeddings to suggest
    films/books based on the user's ratings and notes.
    """
    items = db.query(models.Item).filter(
        models.Item.user_id == current_user.id,
        models.Item.rating >= 4.0
    ).all()

    if not items:
        return {"message": "Rate some items first to get recommendations!"}

    # Placeholder — replace with RAG pipeline in Phase 2
    return {
        "based_on": [item.title for item in items],
        "recommendations": [
            {"title": "Coming soon...", "reason": "AI recommendations will appear here in Phase 2 🚀"}
        ]
    }
